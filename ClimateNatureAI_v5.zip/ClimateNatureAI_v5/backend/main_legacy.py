"""
ClimateNatureAI — Cape Town Total Water Storage (TWS) Forecasting App

Purpose
-------
Predict next-month Total Water Storage (TWS) for Cape Town using the supplied
training-data design:
    TWS_t
    SPEI_1, SPEI_3, SPEI_6, SPEI_12
    SOIL_MOISTURE_t
    latitude, longitude, date

The model follows the challenge rule that, at prediction month t, only data
available at or before t are used.  The target is created by shifting TWS_t
one calendar month forward within each coordinate series:
    target_TWS_t+1 = TWS_(t+1)

Important scientific distinction
--------------------------------
GRACE measures terrestrial water-storage ANOMALIES / equivalent water
thickness at relatively coarse spatial scales.  It does not directly provide
a field-scale absolute "litres of water in Cape Town" measurement. This app
therefore reports:
  1) predicted TWS / TWS anomaly in the same units as Train.csv,
  2) an optional Cape Town-area water-volume equivalent when the model value
     is an equivalent-water-depth quantity (mm).

The volume conversion is:
    volume_m3 = TWS_mm / 1000 * area_m2
    volume_km3 = TWS_mm * area_km2 / 1_000_000

For GRACE anomaly data, the resulting volume is a CHANGE relative to the
product reference mean, not the complete physical water inventory.

Run:
    pip install -r requirements_ClimateNatureAI_TWS.txt
    earthengine authenticate
    python ClimateNatureAI_TWS.py

If Train.csv is present in the working directory, the /api/tws/train endpoint
can train the model.  You can also set TRAIN_CSV=/path/to/Train.csv.
"""

from __future__ import annotations

import json
import os
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from joblib import dump, load

try:
    import ee
except ImportError:
    ee = None


# =============================================================================
# CONFIGURATION
# =============================================================================

APP_NAME = "ClimateNatureAI"
VERSION = "3.0.0-TWS"
GEE_PROJECT = os.getenv("GEE_PROJECT", "ee-ttgintamo")
AOI_ASSET = os.getenv(
    "CLIMATENATUREAI_AOI",
    "projects/ee-ttgintamo/assets/City_of_Cape_Town",
)
TRAIN_CSV = Path(os.getenv("TRAIN_CSV", "Train.csv"))
MODEL_PATH = Path(os.getenv("TWS_MODEL_PATH", "climatenatureai_tws_model.joblib"))
METRICS_PATH = Path(os.getenv("TWS_METRICS_PATH", "climatenatureai_tws_metrics.json"))
DB_PATH = os.getenv("CLIMATENATUREAI_DB", "climatenatureai_groundtruth.sqlite")
HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8000"))

# Approximate only.  For an operational water-volume product, set the exact
# study-area surface area used by the water accounting analysis.
CAPE_TOWN_AREA_KM2 = float(os.getenv("CAPE_TOWN_AREA_KM2", "2445.0"))

# Training controls: the supplied challenge dataset has >2 million rows, so
# default to a bounded sample for an interactive application. Set 0 to use all.
MAX_TRAIN_ROWS = int(os.getenv("MAX_TRAIN_ROWS", "500000"))
RANDOM_STATE = 42

FEATURE_COLUMNS = [
    "TWS_t",
    "SPEI_1",
    "SPEI_3",
    "SPEI_6",
    "SPEI_12",
    "SOIL_MOISTURE_t",
    "latitude",
    "longitude",
    "month_sin",
    "month_cos",
]
TARGET_COLUMN = "TWS_t_plus_1"

# Flexible aliases make the loader robust to common challenge column names.
ALIASES = {
    "TWS_t": ["TWS_t", "TWS", "tws_t", "TWS_T"],
    "SPEI_1": ["SPEI_1", "SPEI1", "SPEI_1_month", "SPEI1_t"],
    "SPEI_3": ["SPEI_3", "SPEI3", "SPEI_3_month", "SPEI3_t"],
    "SPEI_6": ["SPEI_6", "SPEI6", "SPEI_6_month", "SPEI6_t"],
    "SPEI_12": ["SPEI_12", "SPEI12", "SPEI_12_month", "SPEI12_t"],
    "SOIL_MOISTURE_t": [
        "SOIL_MOISTURE_t",
        "SOIL_MOISTURE",
        "soil_moisture_t",
        "soil_moisture",
    ],
    "latitude": ["latitude", "lat", "Latitude"],
    "longitude": ["longitude", "lon", "Longitude"],
    "date": ["date", "Date", "datetime", "month"],
}


# =============================================================================
# MODEL STATE
# =============================================================================

MODEL: Optional[HistGradientBoostingRegressor] = None
MODEL_LOCK = threading.Lock()
MODEL_META: Dict[str, Any] = {}
TRAINING_DATA: Optional[pd.DataFrame] = None


# =============================================================================
# EARTH ENGINE
# =============================================================================

_EE_READY = False


def initialize_ee() -> None:
    global _EE_READY
    if _EE_READY:
        return
    if ee is None:
        raise RuntimeError("earthengine-api is not installed.")
    try:
        ee.Initialize(project=GEE_PROJECT)
    except Exception as exc:
        raise RuntimeError(
            "Earth Engine is not initialized. Run `earthengine authenticate` "
            "or configure a server-side service account."
        ) from exc
    _EE_READY = True


def aoi() -> Any:
    initialize_ee()
    return ee.FeatureCollection(AOI_ASSET).geometry()


def gee_cape_town_predictors() -> Dict[str, float]:
    """Return current predictor values over the Cape Town AOI.

    This is a transparent fallback for the mobile dashboard. The trained
    challenge model itself should be supplied with the same SPEI definitions
    used during training. If those are not available in Earth Engine, the API
    does not silently invent future TWS values; it returns the latest training
    row/nearest-grid prediction path instead.
    """
    region = aoi()

    # Near-surface soil moisture: ERA5-Land volumetric soil water layer 1.
    soil = (
        ee.ImageCollection("ECMWF/ERA5_LAND/DAILY_AGGR")
        .filterBounds(region)
        .filterDate("2026-08-01", "2026-09-01")
        .select("volumetric_soil_water_layer_1")
        .mean()
    )

    # TWS predictor cannot be reconstructed from Sentinel/ERA5 alone without
    # changing the challenge definition. The GRACE layer is therefore exposed
    # separately for monitoring/validation, while ML prediction uses Train.csv.
    soil_value = soil.reduceRegion(
        reducer=ee.Reducer.mean(),
        geometry=region,
        scale=10000,
        bestEffort=True,
        maxPixels=1e7,
    ).getInfo()

    return {
        "soil_moisture": float(soil_value.get("volumetric_soil_water_layer_1"))
        if soil_value.get("volumetric_soil_water_layer_1") is not None
        else float("nan")
    }


def grace_tws_layer() -> Any:
    """Latest GRACE/GRACE-FO land TWS anomaly layer available in EE.

    Dataset choice is kept in one function so it can be replaced with the
    exact GRACE product specified by a study protocol.
    """
    initialize_ee()
    region = aoi()
    collection = ee.ImageCollection(
        "NASA/GRACE/MASS_GRIDS/MASCON_CRI"
    ).filterBounds(region)
    image = collection.sort("system:time_start", False).first()
    return image.clip(region)


def grace_tws_collection() -> Any:
    initialize_ee()
    return ee.ImageCollection("NASA/GRACE/MASS_GRIDS/MASCON_CRI").filterBounds(aoi())


# =============================================================================
# TRAINING DATA
# =============================================================================


def resolve_column(df: pd.DataFrame, logical_name: str) -> str:
    for name in ALIASES[logical_name]:
        if name in df.columns:
            return name
    raise ValueError(
        f"Missing required column for {logical_name}. Expected one of: "
        + ", ".join(ALIASES[logical_name])
    )


def load_train_csv(path: Path = TRAIN_CSV) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            f"Training file not found: {path}. Place Train.csv next to this script "
            "or set TRAIN_CSV=/path/to/Train.csv."
        )

    df = pd.read_csv(path)
    original_rows = len(df)

    # Standardize names without destroying the original data.
    rename_map = {}
    for logical in ALIASES:
        rename_map[resolve_column(df, logical)] = logical
    df = df.rename(columns=rename_map)

    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    for c in ["TWS_t", "SPEI_1", "SPEI_3", "SPEI_6", "SPEI_12", "SOIL_MOISTURE_t", "latitude", "longitude"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=["date", "TWS_t", "latitude", "longitude"])
    df = df.sort_values(["latitude", "longitude", "date"])

    # The target is explicitly one calendar month ahead. Shift only within
    # coordinate series. No future target is used as an input feature.
    group_cols = ["latitude", "longitude"]
    df[TARGET_COLUMN] = df.groupby(group_cols, sort=False)["TWS_t"].shift(-1)

    # Validate that the shifted row is actually the next calendar month.
    next_dates = df.groupby(group_cols, sort=False)["date"].shift(-1)
    month_delta = (
        (next_dates.dt.year - df["date"].dt.year) * 12
        + (next_dates.dt.month - df["date"].dt.month)
    )
    df.loc[month_delta != 1, TARGET_COLUMN] = np.nan

    df["month_sin"] = np.sin(2 * np.pi * (df["date"].dt.month - 1) / 12)
    df["month_cos"] = np.cos(2 * np.pi * (df["date"].dt.month - 1) / 12)

    # Missing predictor values are removed only for the model rows. This is
    # preferable to forward-filling across time because it avoids hidden
    # information leakage.
    model_cols = FEATURE_COLUMNS + [TARGET_COLUMN]
    df = df.dropna(subset=model_cols)

    if MAX_TRAIN_ROWS > 0 and len(df) > MAX_TRAIN_ROWS:
        # Stratified-by-time approximation: retain all years represented in
        # the data while bounding memory/time for an interactive app.
        rng = np.random.default_rng(RANDOM_STATE)
        idx = rng.choice(len(df), size=MAX_TRAIN_ROWS, replace=False)
        df = df.iloc[np.sort(idx)].copy()

    df = df.reset_index(drop=True)
    print(f"Loaded {len(df):,} model rows from {original_rows:,} CSV rows.")
    return df


def time_split(df: pd.DataFrame, test_fraction: float = 0.2) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Chronological split to avoid temporal leakage."""
    dates = np.sort(df["date"].dt.to_period("M").unique())
    if len(dates) < 5:
        train, test = train_test_split(df, test_size=test_fraction, random_state=RANDOM_STATE)
        return train, test
    cutoff_idx = max(1, int(len(dates) * (1 - test_fraction)))
    cutoff = dates[cutoff_idx]
    train = df[df["date"].dt.to_period("M") < cutoff].copy()
    test = df[df["date"].dt.to_period("M") >= cutoff].copy()
    return train, test


def train_tws_model(df: Optional[pd.DataFrame] = None) -> Dict[str, Any]:
    global MODEL, MODEL_META, TRAINING_DATA

    if df is None:
        df = load_train_csv()
    TRAINING_DATA = df

    train_df, test_df = time_split(df)
    X_train = train_df[FEATURE_COLUMNS].astype("float32")
    y_train = train_df[TARGET_COLUMN].astype("float32")
    X_test = test_df[FEATURE_COLUMNS].astype("float32")
    y_test = test_df[TARGET_COLUMN].astype("float32")

    # HistGradientBoosting is scalable and non-linear, while remaining a
    # standard scikit-learn model that is easy to audit and reproduce.
    model = HistGradientBoostingRegressor(
        learning_rate=0.06,
        max_iter=250,
        max_leaf_nodes=63,
        min_samples_leaf=100,
        l2_regularization=1.0,
        random_state=RANDOM_STATE,
    )
    model.fit(X_train, y_train)
    pred = model.predict(X_test)

    metrics = {
        "mae": float(mean_absolute_error(y_test, pred)),
        "rmse": float(np.sqrt(mean_squared_error(y_test, pred))),
        "r2": float(r2_score(y_test, pred)),
        "train_rows": int(len(train_df)),
        "test_rows": int(len(test_df)),
        "train_start": str(train_df["date"].min().date()),
        "train_end": str(train_df["date"].max().date()),
        "test_start": str(test_df["date"].min().date()),
        "test_end": str(test_df["date"].max().date()),
        "features": FEATURE_COLUMNS,
        "target": TARGET_COLUMN,
        "model": "HistGradientBoostingRegressor",
        "random_state": RANDOM_STATE,
        "max_train_rows": MAX_TRAIN_ROWS,
        "trained_at_utc": datetime.now(timezone.utc).isoformat(),
    }

    with MODEL_LOCK:
        MODEL = model
        MODEL_META = metrics
        dump(model, MODEL_PATH)
        METRICS_PATH.write_text(json.dumps(metrics, indent=2), encoding="utf-8")

    return metrics


def load_saved_model() -> bool:
    global MODEL, MODEL_META
    if not MODEL_PATH.exists():
        return False
    try:
        model = load(MODEL_PATH)
        metrics = json.loads(METRICS_PATH.read_text(encoding="utf-8")) if METRICS_PATH.exists() else {}
        with MODEL_LOCK:
            MODEL = model
            MODEL_META = metrics
        return True
    except Exception:
        return False


def ensure_model() -> None:
    if MODEL is not None:
        return
    if load_saved_model():
        return
    raise RuntimeError(
        "No trained TWS model is available. Upload Train.csv and call "
        "POST /api/tws/train first."
    )


# =============================================================================
# PREDICTION
# =============================================================================


def nearest_training_row(lat: float, lon: float) -> pd.Series:
    global TRAINING_DATA
    if TRAINING_DATA is None:
        TRAINING_DATA = load_train_csv()
    d2 = (TRAINING_DATA["latitude"] - lat) ** 2 + (TRAINING_DATA["longitude"] - lon) ** 2
    return TRAINING_DATA.loc[d2.idxmin()]


def predict_from_features(features: Dict[str, float]) -> float:
    ensure_model()
    missing = [c for c in FEATURE_COLUMNS if c not in features]
    if missing:
        raise ValueError(f"Missing model features: {missing}")
    x = pd.DataFrame([[features[c] for c in FEATURE_COLUMNS]], columns=FEATURE_COLUMNS)
    with MODEL_LOCK:
        return float(MODEL.predict(x.astype("float32"))[0])


def water_volume_from_mm(tws_mm: float, area_km2: float) -> Dict[str, float]:
    volume_m3 = tws_mm / 1000.0 * area_km2 * 1_000_000.0
    return {
        "area_km2": float(area_km2),
        "equivalent_water_depth_mm": float(tws_mm),
        "equivalent_volume_m3": float(volume_m3),
        "equivalent_volume_km3": float(volume_m3 / 1_000_000_000.0),
    }


def build_prediction_for_location(
    lat: float,
    lon: float,
    date: Optional[str] = None,
    spei_1: Optional[float] = None,
    spei_3: Optional[float] = None,
    spei_6: Optional[float] = None,
    spei_12: Optional[float] = None,
    soil_moisture: Optional[float] = None,
) -> Dict[str, Any]:
    ensure_model()
    if TRAINING_DATA is None:
        load_train_csv()

    query_date = pd.Timestamp(date) if date else pd.Timestamp.utcnow().normalize()
    row = nearest_training_row(lat, lon)

    # For prediction-time covariates, caller-provided values take precedence.
    # Otherwise use the latest available training-time value at the nearest
    # coordinate. This is not a substitute for a real operational SPEI feed.
    history = TRAINING_DATA[
        (TRAINING_DATA["latitude"] == row["latitude"])
        & (TRAINING_DATA["longitude"] == row["longitude"])
        & (TRAINING_DATA["date"] <= query_date)
    ].sort_values("date")
    if history.empty:
        history = TRAINING_DATA[
            (TRAINING_DATA["latitude"] == row["latitude"])
            & (TRAINING_DATA["longitude"] == row["longitude"])
        ].sort_values("date")
    current = history.iloc[-1]

    sm = soil_moisture if soil_moisture is not None else float(current["SOIL_MOISTURE_t"])
    s1 = spei_1 if spei_1 is not None else float(current["SPEI_1"])
    s3 = spei_3 if spei_3 is not None else float(current["SPEI_3"])
    s6 = spei_6 if spei_6 is not None else float(current["SPEI_6"])
    s12 = spei_12 if spei_12 is not None else float(current["SPEI_12"])

    # TWS_t is a legitimate predictor only when it is observed at prediction
    # time. If the current TWS is masked, do NOT fill it from future TWS.
    tws_current = float(current["TWS_t"])
    month = query_date.month
    features = {
        "TWS_t": tws_current,
        "SPEI_1": s1,
        "SPEI_3": s3,
        "SPEI_6": s6,
        "SPEI_12": s12,
        "SOIL_MOISTURE_t": sm,
        "latitude": float(lat),
        "longitude": float(lon),
        "month_sin": float(np.sin(2 * np.pi * (month - 1) / 12)),
        "month_cos": float(np.cos(2 * np.pi * (month - 1) / 12)),
    }
    prediction = predict_from_features(features)
    volume = water_volume_from_mm(prediction, CAPE_TOWN_AREA_KM2)

    return {
        "location": {"latitude": lat, "longitude": lon},
        "prediction_month": str(query_date.to_period("M")),
        "forecast_target": "next calendar month (t+1)",
        "predicted_TWS": prediction,
        "units": "same TWS units as Train.csv; volume conversion assumes mm",
        "water_volume_if_mm": volume,
        "predictors": features,
        "nearest_training_grid": {
            "latitude": float(row["latitude"]),
            "longitude": float(row["longitude"]),
            "source_date": str(pd.Timestamp(current["date"]).date()),
        },
        "model": MODEL_META,
        "leakage_guard": "No future observed TWS is used to fill masked TWS_t.",
    }


# =============================================================================
# GRACE / GEE MAP LAYER
# =============================================================================

LAYER_CATALOG = {
    "grace_tws": {"title": "GRACE TWS anomaly", "group": "Water Storage"},
    "elevation": {"title": "Elevation", "group": "Terrain"},
    "ndvi": {"title": "Vegetation / NDVI", "group": "Nature"},
    "surface_water": {"title": "Surface Water", "group": "Water"},
    "drought": {"title": "Drought Index", "group": "Climate"},
}


def gee_ndvi() -> Any:
    region = aoi()
    ic = (
        ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")
        .filterBounds(region)
        .filterDate("2025-01-01", "2026-01-01")
        .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE", 30))
    )
    return ic.map(lambda img: img.normalizedDifference(["B8", "B4"]).rename("ndvi")).median().clip(region)


def gee_surface_water() -> Any:
    return ee.Image("JRC/GSW1_4/GlobalSurfaceWater").select("occurrence").clip(aoi())


def gee_elevation() -> Any:
    return ee.Image("MERIT/DEM/v1_0_3").select("dem").clip(aoi())


def gee_drought() -> Any:
    region = aoi()
    recent = ee.ImageCollection("UCSB-CHG/CHIRPS/DAILY").filterBounds(region).filterDate("2025-09-01", "2026-09-01").sum()
    baseline = ee.ImageCollection("UCSB-CHG/CHIRPS/DAILY").filterBounds(region).filterDate("2000-09-01", "2025-09-01").sum().divide(25)
    anomaly = recent.subtract(baseline).divide(baseline.abs().max(1))
    return anomaly.multiply(-1).add(1).clamp(0, 1).rename("drought").clip(region)


BUILDERS = {
    "grace_tws": (grace_tws_layer, {"min": -30, "max": 30, "palette": ["b2182b", "fddbc7", "d1e5f0", "2166ac"]}),
    "elevation": (gee_elevation, {"min": 0, "max": 500, "palette": ["081c15", "52b788", "f1faee"]}),
    "ndvi": (gee_ndvi, {"min": -0.1, "max": 0.8, "palette": ["6b2d2d", "e9c46a", "2a9d8f"]}),
    "surface_water": (gee_surface_water, {"min": 0, "max": 100, "palette": ["f7fbff", "74add1", "2166ac"]}),
    "drought": (gee_drought, {"min": 0, "max": 1, "palette": ["1a9850", "fee08b", "d73027"]}),
}


def tile_url(layer_name: str) -> str:
    if layer_name not in BUILDERS:
        raise HTTPException(status_code=404, detail="Unknown layer")
    image = BUILDERS[layer_name][0]()
    return image.getMapId(BUILDERS[layer_name][1])["tile_fetcher"].url_format


def sample_grace(lat: float, lon: float) -> Optional[float]:
    image = grace_tws_layer()
    point = ee.Geometry.Point([lon, lat])
    result = image.reduceRegion(
        reducer=ee.Reducer.mean(),
        geometry=point,
        scale=25000,
        bestEffort=True,
        maxPixels=1e7,
    ).getInfo()
    if not result:
        return None
    value = next(iter(result.values()), None)
    return float(value) if value is not None else None


# =============================================================================
# FASTAPI + GROUNDTRUTH
# =============================================================================

app = FastAPI(title=APP_NAME, version=VERSION)
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def init_db() -> None:
    con = sqlite3.connect(DB_PATH)
    con.execute(
        """CREATE TABLE IF NOT EXISTS observations (
            observation_id TEXT PRIMARY KEY,
            latitude REAL NOT NULL,
            longitude REAL NOT NULL,
            observation_type TEXT NOT NULL,
            surface_water TEXT,
            notes TEXT,
            observer TEXT,
            observation_date TEXT,
            created_at TEXT NOT NULL
        )"""
    )
    con.commit()
    con.close()


class TWSRequest(BaseModel):
    lat: float = Field(ge=-90, le=90)
    lon: float = Field(ge=-180, le=180)
    date: Optional[str] = None
    spei_1: Optional[float] = None
    spei_3: Optional[float] = None
    spei_6: Optional[float] = None
    spei_12: Optional[float] = None
    soil_moisture: Optional[float] = None


class Groundtruth(BaseModel):
    observation_id: str
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    observation_type: str
    surface_water: Optional[str] = None
    notes: Optional[str] = None
    observer: Optional[str] = None
    observation_date: Optional[str] = None


@app.on_event("startup")
def startup() -> None:
    init_db()
    # Loading a saved model is cheap; training is deliberately not automatic.
    load_saved_model()


@app.get("/api/health")
def health() -> Dict[str, Any]:
    return {
        "status": "ok",
        "service": APP_NAME,
        "version": VERSION,
        "gee_project": GEE_PROJECT,
        "aoi_asset": AOI_ASSET,
        "train_csv": str(TRAIN_CSV),
        "model_ready": MODEL is not None,
        "time": datetime.now(timezone.utc).isoformat(),
    }


@app.post("/api/tws/train")
def train_endpoint() -> Dict[str, Any]:
    try:
        df = load_train_csv()
        return train_tws_model(df)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/tws/metrics")
def tws_metrics() -> Dict[str, Any]:
    if not MODEL_META and METRICS_PATH.exists():
        return json.loads(METRICS_PATH.read_text(encoding="utf-8"))
    return MODEL_META


@app.post("/api/tws/predict")
def tws_predict(req: TWSRequest) -> Dict[str, Any]:
    try:
        return build_prediction_for_location(
            req.lat,
            req.lon,
            req.date,
            req.spei_1,
            req.spei_3,
            req.spei_6,
            req.spei_12,
            req.soil_moisture,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/tws/cape-town")
def cape_town_tws(
    date: Optional[str] = None,
    area_km2: float = Query(CAPE_TOWN_AREA_KM2, gt=0),
) -> Dict[str, Any]:
    """Predict next-month TWS for the Cape Town AOI using Train.csv."""
    try:
        result = build_prediction_for_location(-33.9258, 18.4232, date)
        if result.get("water_volume_if_mm"):
            result["water_volume_if_mm"] = water_volume_from_mm(result["predicted_TWS"], area_km2)
        return result
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/grace/cape-town")
def cape_town_grace() -> Dict[str, Any]:
    try:
        value = sample_grace(-33.9258, 18.4232)
        return {
            "location": {"latitude": -33.9258, "longitude": 18.4232},
            "grace_tws_anomaly": value,
            "note": "GRACE is a coarse-scale TWS anomaly observation; use as validation/monitoring, not a field-scale absolute water inventory.",
        }
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/layers")
def layers() -> Dict[str, Any]:
    return {"layers": {k: {**v, "endpoint": f"/api/layers/{k}"} for k, v in LAYER_CATALOG.items()}}


@app.get("/api/layers/{layer_name}")
def get_layer(layer_name: str) -> Dict[str, Any]:
    return {"name": layer_name, "title": LAYER_CATALOG.get(layer_name, {}).get("title", layer_name), "tile_url": tile_url(layer_name)}


@app.post("/api/groundtruth")
def groundtruth(obs: Groundtruth) -> Dict[str, Any]:
    con = sqlite3.connect(DB_PATH)
    try:
        con.execute(
            "INSERT OR REPLACE INTO observations VALUES (?,?,?,?,?,?,?,?)",
            (
                obs.observation_id,
                obs.latitude,
                obs.longitude,
                obs.observation_type,
                obs.surface_water,
                obs.notes,
                obs.observer,
                obs.observation_date,
            ),
        )
        con.commit()
    finally:
        con.close()
    return {"status": "received", "observation_id": obs.observation_id}


# =============================================================================
# MOBILE UI
# =============================================================================

INDEX_HTML = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#07100c"><title>ClimateNatureAI — Water Intelligence</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>
:root{--bg:#07100c;--panel:#101914;--line:#294037;--text:#edf5ef;--muted:#91a39a;--green:#56d39b;--blue:#5fb3ff;--amber:#f0bd69;--red:#ff7b72}
*{box-sizing:border-box}html,body,#app{margin:0;height:100%;background:var(--bg);color:var(--text);font-family:system-ui,-apple-system,Segoe UI,sans-serif}body{overflow:hidden}
#map{position:absolute;inset:0}header{position:absolute;z-index:900;top:0;left:0;right:0;padding:15px 15px 40px;background:linear-gradient(#07100cf5,#07100c88,transparent);pointer-events:none}
.brand{display:flex;gap:10px;align-items:center}.logo{width:42px;height:42px;border-radius:13px;background:var(--green);color:#06110b;display:grid;place-items:center;font-weight:900}.brand h1{font-size:18px;margin:0}.brand p{font-size:9px;color:var(--muted);margin:2px 0}
.controls{position:absolute;z-index:901;top:77px;left:14px;right:14px;display:flex;gap:7px}.search{flex:1}input,select,textarea{background:#0d1712;color:var(--text);border:1px solid var(--line);border-radius:13px;padding:10px;outline:0;width:100%}button{border:1px solid var(--line);background:#101914;color:var(--text);border-radius:13px;padding:10px 12px;cursor:pointer}
.place{position:absolute;z-index:900;left:14px;right:14px;bottom:84px;background:#0b1510ee;border:1px solid var(--line);border-radius:22px;padding:14px;box-shadow:0 12px 35px #0008}.place h2{font:21px Georgia,serif;margin:0}.muted,.meta{color:var(--muted);font-size:10px;line-height:1.5}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-top:9px}.mini{background:#101914;border:1px solid var(--line);border-radius:13px;padding:9px}.mini b{display:block;font-size:16px}.mini span{font-size:9px;color:var(--muted)}
.water{margin-top:9px;background:#0d1712;border:1px solid #315066;border-radius:15px;padding:10px}.water b{font-size:22px;color:var(--blue)}.water span{display:block;color:var(--muted);font-size:9px}.badge{font-size:9px;border:1px solid var(--line);border-radius:99px;padding:4px 7px;color:var(--muted)}
.nav{position:absolute;z-index:1000;bottom:0;left:0;right:0;padding:7px 7px calc(env(safe-area-inset-bottom)+7px);background:#07100cf7;border-top:1px solid var(--line);display:grid;grid-template-columns:repeat(5,1fr)}.nav button{border:0;background:none;color:var(--muted);font-size:10px}.nav button.active{color:var(--green)}.nav i{display:block;font-style:normal;font-size:20px;margin-bottom:2px}
.sheet{position:absolute;z-index:1100;left:0;right:0;bottom:0;height:80dvh;background:#0b1510;border-top:1px solid var(--line);border-radius:25px 25px 0 0;padding:16px 15px 100px;overflow:auto;transform:translateY(105%);transition:.25s}.sheet.open{transform:none}.sheethead{display:flex;justify-content:space-between;align-items:center;margin-bottom:13px}.sheet h2{font:25px Georgia,serif;margin:0}.card{background:#101914;border:1px solid var(--line);border-radius:19px;padding:14px;margin-bottom:10px}.card h3{font:18px Georgia,serif;margin:0 0 6px}.value{font-size:21px;font-weight:800;color:var(--green)}.notice{border-left:3px solid var(--amber);background:#17231d;padding:10px;border-radius:9px;font-size:11px;line-height:1.5}.primary{background:var(--green);color:#06110b;font-weight:800;width:100%}.danger{color:var(--red)}.kv{display:grid;grid-template-columns:1fr 1fr;gap:7px}.kv div{background:#0d1712;padding:9px;border-radius:12px}.kv b{display:block;font-size:15px}.kv span{font-size:9px;color:var(--muted)}
@media(min-width:800px){.place{width:410px;right:auto;left:24px}.sheet{left:auto;width:500px}}
</style></head>
<body><div id="app"><header><div class="brand"><div class="logo">CN</div><div><h1>ClimateNatureAI</h1><p>Climate • Water • Biodiversity • Nature-based Solutions Intelligence</p></div></div></header>
<div id="map"></div><div class="controls"><input id="search" class="search" placeholder="Search Cape Town place…"><button id="locate">⌖</button><button id="refresh">↻</button></div>
<div class="place"><div style="display:flex;justify-content:space-between;gap:8px"><h2>Cape Town Water Intelligence</h2><span id="status" class="badge">Ready</span></div><div id="coords" class="muted">GRACE + ML TWS forecasting</div><div class="water"><b id="tws">—</b><span>Predicted next-month TWS / TWS anomaly</span><div class="meta" id="volume">Water-volume equivalent: —</div></div><div class="grid"><div class="mini"><b id="mae">—</b><span>Model MAE</span></div><div class="mini"><b id="r2">—</b><span>Validation R²</span></div><div class="mini"><b id="grace">—</b><span>GRACE now</span></div></div></div>
<div id="sheet" class="sheet"><div class="sheethead"><h2 id="title">Water</h2><button onclick="closeSheet()">Close</button></div><div id="content"></div></div>
<nav class="nav"><button data-p="map" class="active"><i>⌖</i>Map</button><button data-p="water"><i>≈</i>Water</button><button data-p="layers"><i>▱</i>Layers</button><button data-p="model"><i>✦</i>Model</button><button data-p="field"><i>◇</i>Field</button></nav></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script><script>
const API="";let map,marker,pred=null,grace=null,layers={};let selected={lat:-33.9258,lon:18.4232};
function init(){map=L.map("map",{zoomControl:false}).setView([selected.lat,selected.lon],10);L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:"© OpenStreetMap"}).addTo(map);marker=L.marker([selected.lat,selected.lon]).addTo(map);map.on("click",e=>select(e.latlng.lat,e.latlng.lng));refresh()}
async function api(url,opt={}){let r=await fetch(API+url,opt);if(!r.ok){let t=await r.text();throw Error(t)}return r.json()}
async function refresh(){document.getElementById("status").textContent="Loading…";try{pred=await api(`/api/tws/cape-town`);grace=await api(`/api/grace/cape-town`);render();document.getElementById("status").textContent="● Connected"}catch(e){document.getElementById("status").textContent="● Train model first";console.error(e)}}
async function select(lat,lon){selected={lat,lon};marker.setLatLng([lat,lon]);document.getElementById("coords").textContent=`${lat.toFixed(5)}, ${lon.toFixed(5)} • next-month forecast`;try{pred=await api(`/api/tws/predict`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({lat,lon})});render()}catch(e){document.getElementById("status").textContent="● Prediction unavailable"}}
function fmt(x,d=2){return x==null||Number.isNaN(Number(x))?"—":Number(x).toFixed(d)}
function render(){if(!pred)return;document.getElementById("tws").textContent=fmt(pred.predicted_TWS,2)+" mm";document.getElementById("volume").textContent=`Water-volume equivalent ≈ ${fmt(pred.water_volume_if_mm.equivalent_volume_km3,3)} km³ (if TWS is mm)`;document.getElementById("mae").textContent=fmt(pred.model.mae,2);document.getElementById("r2").textContent=fmt(pred.model.r2,2);document.getElementById("grace").textContent=grace?.grace_tws_anomaly==null?"—":fmt(grace.grace_tws_anomaly,1)}
function closeSheet(){document.getElementById("sheet").classList.remove("open")}
function openPanel(p){document.querySelectorAll(".nav button").forEach(b=>b.classList.toggle("active",b.dataset.p===p));if(p==="map"){closeSheet();return}document.getElementById("sheet").classList.add("open");document.getElementById("title").textContent={water:"Water Intelligence",layers:"Layers",model:"TWS Model",field:"Groundtruth"}[p];document.getElementById("content").innerHTML=p==="water"?waterPanel():p==="layers"?layersPanel():p==="model"?modelPanel():fieldPanel()}
function waterPanel(){return `<div class="card"><h3>How much water?</h3><div class="value">${fmt(pred?.predicted_TWS,2)} mm</div><div class="meta">This is the predicted next-month TWS value in the same units as Train.csv. If the training target is GRACE equivalent-water-thickness in millimetres, ${fmt(pred?.water_volume_if_mm?.equivalent_volume_km3,3)} km³ is the corresponding Cape Town-area equivalent. For anomalies, this is a change relative to the product reference mean—not total physical water stored.</div></div><div class="card"><h3>Prediction chain</h3><div class="notice">Observed TWS_t + SPEI(1/3/6/12) + soil moisture + location + month → ML model → TWS(t+1). Future observed TWS is never used to fill a masked TWS_t.</div></div><div class="card"><h3>GRACE role</h3><div class="meta">GRACE/GRACE-FO provides an independent monthly water-storage observation for validation and monitoring. It is coarse-scale, so this app should be interpreted as a downscaled/modelled Cape Town screening product.</div></div>`}
function layersPanel(){return `<div class="card"><h3>Water layers</h3>${[["grace_tws","GRACE TWS anomaly"],["drought","Drought Index"],["surface_water","Surface Water"],["ndvi","Vegetation / NDVI"],["elevation","Elevation"]].map(x=>`<label style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #29403788">${x[1]}<input type="checkbox" style="width:22px" onchange="toggleLayer('${x[0]}',this.checked)"></label>`).join("")}</div>`}
async function toggleLayer(name,on){try{if(!layers[name]){let d=await api(`/api/layers/${name}`);layers[name]=L.tileLayer(d.tile_url,{opacity:.7,attribution:"ClimateNatureAI / GEE"})}if(on)layers[name].addTo(map);else map.removeLayer(layers[name])}catch(e){alert("Layer unavailable: "+name)}}
function modelPanel(){return `<div class="card"><h3>Model validation</h3><div class="kv"><div><b>${fmt(pred?.model.mae,2)}</b><span>MAE</span></div><div><b>${fmt(pred?.model.rmse,2)}</b><span>RMSE</span></div><div><b>${fmt(pred?.model.r2,2)}</b><span>R²</span></div><div><b>${pred?.model.test_rows||"—"}</b><span>Test rows</span></div></div></div><div class="card"><h3>Features</h3><div class="meta">TWS_t • SPEI_1 • SPEI_3 • SPEI_6 • SPEI_12 • SOIL_MOISTURE_t • latitude • longitude • seasonal month terms</div></div><div class="notice">Research warning: do not describe the output as an absolute reservoir inventory. GRACE measures large-area storage changes; local downscaling requires validation.</div>`}
function fieldPanel(){return `<div class="card"><h3>Groundtruth</h3><div class="meta">Use field observations to validate water bodies, wetlands, vegetation condition and NbS opportunities. Mergin Maps/QGIS can be used for synchronized field evidence.</div><button class="primary" onclick="submitGT()">Record Cape Town Water Check</button></div><div id="gt"></div>`}
async function submitGT(){try{let r=await api("/api/groundtruth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({observation_id:"GT-"+Date.now(),latitude:selected.lat,longitude:selected.lon,observation_type:"water_storage_check",surface_water:"Field check required",notes:"ClimateNatureAI field validation",observer:"ClimateNatureAI Mobile",observation_date:new Date().toISOString()})});document.getElementById("gt").innerHTML=`<div class="card">Groundtruth saved: ${r.observation_id}</div>`}catch(e){document.getElementById("gt").innerHTML=`<div class="card danger">Groundtruth unavailable.</div>`}}
document.querySelectorAll(".nav button").forEach(b=>b.onclick=()=>openPanel(b.dataset.p));document.getElementById("refresh").onclick=refresh;document.getElementById("locate").onclick=()=>navigator.geolocation?.getCurrentPosition(p=>select(p.coords.latitude,p.coords.longitude));document.getElementById("search").onkeydown=async e=>{if(e.key!=="Enter")return;let q=e.target.value.trim();if(!q)return;try{let r=await fetch("https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=za&q="+encodeURIComponent(q+", Cape Town"));let a=await r.json();if(a[0])select(+a[0].lat,+a[0].lon)}catch(x){alert("Search unavailable")}};init();
</script></body></html>'''


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    return INDEX_HTML


# =============================================================================
# SERVER LAUNCHERS
# =============================================================================


def run_server() -> None:
    import uvicorn
    uvicorn.run("ClimateNatureAI_TWS:app", host=HOST, port=PORT, reload=False)


async def serve_in_notebook() -> None:
    import uvicorn
    config = uvicorn.Config(app, host=HOST, port=PORT, log_level="info")
    server = uvicorn.Server(config)
    await server.serve()


if __name__ == "__main__":
    run_server()

# =============================================================================
# v4 API COMPATIBILITY / MOBILE PLATFORM ROUTES
# =============================================================================

@app.get('/api/v1/water/cape-town')
def v1_cape_town_water() -> Dict[str, Any]:
    """Mobile-friendly water intelligence endpoint."""
    try:
        pred = build_prediction_for_location(-33.9258, 18.4232)
        grace = None
        try:
            grace = sample_grace(-33.9258, 18.4232)
        except Exception:
            pass
        p = float(pred['predicted_TWS'])
        volume = water_volume_from_mm(p, CAPE_TOWN_AREA_KM2)['equivalent_volume_km3']
        status = 'Low water storage' if p < 0 else 'Moderate water storage'
        return {'location':'Cape Town','prediction':round(p,3),'water_volume':round(volume,4),
                'grace_tws_anomaly':grace,'status':status,'forecast_target':'t+1','units':'mm'}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@app.get('/api/v1/layers')
def v1_layers():
    return layers()

@app.get('/api/v1/health')
def v1_health():
    return health()

@app.get('/api/v1/water/tws')
def v1_tws(lat: float = Query(-33.9258), lon: float = Query(18.4232)):
    return {'latitude':lat,'longitude':lon,'prediction':build_prediction_for_location(lat,lon)['predicted_TWS']}

@app.get('/api/v1/ai/assessment')
def v1_ai_assessment(lat: float = Query(-33.9258), lon: float = Query(18.4232)):
    result = build_prediction_for_location(lat, lon)
    p = result['predicted_TWS']
    return {'location':{'latitude':lat,'longitude':lon},'assessment':
            'Predicted TWS is below zero relative to the model reference.' if p < 0 else
            'Predicted TWS is non-negative relative to the model reference.',
            'predicted_TWS':p,'explainability':{'features':FEATURE_COLUMNS,
            'note':'Use SHAP or permutation importance in production for model-level/local explanations.'}}
