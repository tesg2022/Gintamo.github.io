from __future__ import annotations
import hashlib, json, logging, os, secrets, sqlite3, threading, uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional

import numpy as np
import pandas as pd
from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GroupShuffleSplit
from joblib import dump, load

try:
    import ee
except Exception:
    ee = None

APP = "ClimateNatureAI"
VERSION = "5.0.0-research-operational"
BASE = Path(__file__).resolve().parents[2]
DATA_DIR = Path(os.getenv("DATA_DIR", BASE / "data"))
MODEL_DIR = Path(os.getenv("MODEL_DIR", BASE / "models"))
TRAIN_CSV = Path(os.getenv("TRAIN_CSV", DATA_DIR / "Train.csv"))
MODEL_PATH = MODEL_DIR / "tws_hgb.joblib"
META_PATH = MODEL_DIR / "tws_metadata.json"
DB_PATH = Path(os.getenv("DB_PATH", BASE / "data" / "climatenatureai.db"))
GEE_PROJECT = os.getenv("GEE_PROJECT", "ee-ttgintamo")
AOI_ASSET = os.getenv("CLIMATENATUREAI_AOI", "projects/ee-ttgintamo/assets/City_of_Cape_Town")
CAPE_TOWN_AREA_KM2 = float(os.getenv("CAPE_TOWN_AREA_KM2", "2445"))
CORS = os.getenv("CORS_ORIGINS", "http://localhost:3000,http://localhost:8000").split(",")
JWT_SECRET = os.getenv("JWT_SECRET", "CHANGE_ME_IN_PRODUCTION")
MAX_TRAIN_ROWS = int(os.getenv("MAX_TRAIN_ROWS", "0"))

FEATURES = ["TWS_t", "SPEI_1", "SPEI_3", "SPEI_6", "SPEI_12", "SOIL_MOISTURE_t", "latitude", "longitude", "month_sin", "month_cos"]
ALIASES = {
    "TWS_t": ["TWS_t", "TWS", "tws_t"], "SPEI_1": ["SPEI_1", "SPEI1"],
    "SPEI_3": ["SPEI_3", "SPEI3"], "SPEI_6": ["SPEI_6", "SPEI6"],
    "SPEI_12": ["SPEI_12", "SPEI12"],
    "SOIL_MOISTURE_t": ["SOIL_MOISTURE_t", "SOIL_MOISTURE", "soil_moisture"],
    "latitude": ["latitude", "lat", "Latitude"], "longitude": ["longitude", "lon", "Longitude"],
    "date": ["date", "Date", "datetime", "month"],
}

MODEL = None
META: dict[str, Any] = {}
LOCK = threading.Lock()
EE_READY = False
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
log = logging.getLogger(APP)


def db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,plan TEXT NOT NULL DEFAULT 'free',created_at TEXT NOT NULL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS groundtruth(id TEXT PRIMARY KEY,lat REAL NOT NULL,lon REAL NOT NULL,kind TEXT NOT NULL,value TEXT,notes TEXT,observed_at TEXT NOT NULL,user_id TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT,action TEXT,created_at TEXT,details TEXT)""")


def hash_pw(p: str, salt: str | None = None):
    salt = salt or secrets.token_hex(16)
    return salt + "$" + hashlib.pbkdf2_hmac("sha256", p.encode(), salt.encode(), 180_000).hex()


def verify_pw(p: str, stored: str):
    salt, digest = stored.split("$", 1)
    return secrets.compare_digest(hash_pw(p, salt).split("$", 1)[1], digest)


def token(user_id: str):
    import base64
    payload = f"{user_id}.{int((datetime.now(timezone.utc)+timedelta(hours=12)).timestamp())}.{JWT_SECRET}"
    return base64.urlsafe_b64encode(payload.encode()).decode()


def current_user(authorization: str | None = Header(default=None)):
    if not authorization or not authorization.startswith("Bearer "):
        return None
    import base64
    try:
        raw = base64.urlsafe_b64decode(authorization[7:].encode()).decode()
        uid, exp, secret = raw.split(".", 2)
        if secret != JWT_SECRET or int(exp) < int(datetime.now(timezone.utc).timestamp()): return None
        with db() as c: row = c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
        return dict(row) if row else None
    except Exception: return None


def require_user(user=Depends(current_user)):
    if not user: raise HTTPException(401, "Authentication required")
    return user


def init_ee():
    global EE_READY
    if EE_READY: return
    if ee is None: raise RuntimeError("earthengine-api is not installed")
    ee.Initialize(project=GEE_PROJECT); EE_READY = True


def aoi():
    init_ee(); return ee.FeatureCollection(AOI_ASSET).geometry()


def column(df, key):
    for x in ALIASES[key]:
        if x in df.columns: return x
    raise ValueError(f"Missing {key}; accepted names: {ALIASES[key]}")


def load_data():
    if not TRAIN_CSV.exists(): raise FileNotFoundError(f"Train.csv not found: {TRAIN_CSV}")
    df = pd.read_csv(TRAIN_CSV)
    rename = {column(df,k): k for k in ALIASES}
    df = df.rename(columns=rename)
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    numeric = [k for k in ALIASES if k != "date"]
    for k in numeric: df[k] = pd.to_numeric(df[k], errors="coerce")
    df = df.dropna(subset=["date", "TWS_t", "latitude", "longitude"])
    df = df.sort_values(["latitude", "longitude", "date"])
    grp = ["latitude", "longitude"]
    df["target_TWS_t1"] = df.groupby(grp)["TWS_t"].shift(-1)
    nd = df.groupby(grp)["date"].shift(-1)
    delta = (nd.dt.year-df.date.dt.year)*12 + nd.dt.month-df.date.dt.month
    df.loc[delta != 1, "target_TWS_t1"] = np.nan
    m = df.date.dt.month
    df["month_sin"] = np.sin(2*np.pi*(m-1)/12); df["month_cos"] = np.cos(2*np.pi*(m-1)/12)
    df = df.dropna(subset=FEATURES+["target_TWS_t1"]).reset_index(drop=True)
    if MAX_TRAIN_ROWS and len(df)>MAX_TRAIN_ROWS:
        df=df.sample(MAX_TRAIN_ROWS, random_state=42).sort_values("date").reset_index(drop=True)
    return df


def train():
    df=load_data()
    # Time holdout: final 20% of calendar months.
    months=np.sort(df.date.dt.to_period("M").unique()); cut=months[max(1,int(len(months)*.8))]
    tr=df[df.date.dt.to_period("M")<cut]; te=df[df.date.dt.to_period("M")>=cut]
    model=HistGradientBoostingRegressor(learning_rate=.05,max_iter=350,max_leaf_nodes=63,min_samples_leaf=80,l2_regularization=2,random_state=42)
    model.fit(tr[FEATURES].astype("float32"),tr.target_TWS_t1.astype("float32")); p=model.predict(te[FEATURES].astype("float32"))
    # Persistence benchmark is the strongest sanity check for short-memory TWS forecasting.
    base=te.TWS_t.to_numpy()
    metrics={"model":{"mae":float(mean_absolute_error(te.target_TWS_t1,p)),"rmse":float(np.sqrt(mean_squared_error(te.target_TWS_t1,p))),"r2":float(r2_score(te.target_TWS_t1,p))},
             "persistence_baseline":{"mae":float(mean_absolute_error(te.target_TWS_t1,base)),"rmse":float(np.sqrt(mean_squared_error(te.target_TWS_t1,base))),"r2":float(r2_score(te.target_TWS_t1,base))},
             "rows":{"all":len(df),"train":len(tr),"test":len(te)},"period":{"train_start":str(tr.date.min().date()),"train_end":str(tr.date.max().date()),"test_start":str(te.date.min().date()),"test_end":str(te.date.max().date())},"features":FEATURES,"target":"target_TWS_t1","trained_at":datetime.now(timezone.utc).isoformat(),"data_policy":"target is next observed calendar month; no future TWS is used as an input"}
    MODEL_DIR.mkdir(parents=True,exist_ok=True); dump(model,MODEL_PATH); META_PATH.write_text(json.dumps(metrics,indent=2));
    global MODEL,META
    with LOCK: MODEL,META=model,metrics
    return metrics


def ensure_model():
    global MODEL,META
    if MODEL is not None:return
    if MODEL_PATH.exists():
        MODEL=load(MODEL_PATH); META=json.loads(META_PATH.read_text()) if META_PATH.exists() else {}
    else: raise HTTPException(503,"TWS model is not trained. POST /api/v1/admin/tws/train")


def volume(mm):
    m3=mm/1000*CAPE_TOWN_AREA_KM2*1e6
    return {"depth_mm":mm,"volume_m3":m3,"volume_km3":m3/1e9,"interpretation":"equivalent depth/volume; for anomaly TWS this is change relative to product reference"}


def predict(req):
    ensure_model(); x=req.model_dump(); dt=pd.Timestamp(x.get("date") or datetime.now(timezone.utc));
    vals={"TWS_t":x["TWS_t"],"SPEI_1":x["spei_1"],"SPEI_3":x["spei_3"],"SPEI_6":x["spei_6"],"SPEI_12":x["spei_12"],"SOIL_MOISTURE_t":x["soil_moisture"],"latitude":x["lat"],"longitude":x["lon"],"month_sin":np.sin(2*np.pi*(dt.month-1)/12),"month_cos":np.cos(2*np.pi*(dt.month-1)/12)}
    y=float(MODEL.predict(pd.DataFrame([vals])[FEATURES].astype("float32"))[0]); return {"forecast_target":str((dt.to_period("M")+1)),"predicted_TWS":y,"units":"same as Train.csv","equivalent_water":volume(y),"predictors":vals,"model":META,"leakage_guard":"All predictors are explicitly supplied for prediction time; the API does not impute future TWS."}


class Register(BaseModel): email:str; password:str=Field(min_length=8)
class Login(Register): pass
class TWSRequest(BaseModel):
    lat:float=Field(ge=-90,le=90); lon:float=Field(ge=-180,le=180); date:Optional[str]=None
    TWS_t:float; spei_1:float; spei_3:float; spei_6:float; spei_12:float; soil_moisture:float
class Groundtruth(BaseModel): lat:float; lon:float; kind:str; value:Optional[str]=None; notes:Optional[str]=None; observed_at:Optional[str]=None

app=FastAPI(title=APP,version=VERSION,description="Research + operational climate, water, nature and NbS intelligence API")
app.add_middleware(CORSMiddleware,allow_origins=CORS,allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
init_db()

@app.get("/api/v1/health")
def health(): return {"status":"ok","version":VERSION,"model_available":MODEL_PATH.exists(),"gee_configured":ee is not None}

@app.post("/api/v1/auth/register")
def register(r:Register):
    uid=str(uuid.uuid4())
    try:
        with db() as c:c.execute("INSERT INTO users VALUES(?,?,?,?,?)",(uid,r.email.lower(),hash_pw(r.password),"free",datetime.now(timezone.utc).isoformat()))
    except sqlite3.IntegrityError: raise HTTPException(409,"Email already registered")
    return {"user_id":uid,"access_token":token(uid),"plan":"free"}

@app.post("/api/v1/auth/login")
def login(r:Login):
    with db() as c: row=c.execute("SELECT * FROM users WHERE email=?",(r.email.lower(),)).fetchone()
    if not row or not verify_pw(r.password,row["password_hash"]): raise HTTPException(401,"Invalid credentials")
    return {"access_token":token(row["id"]),"plan":row["plan"]}

@app.post("/api/v1/admin/tws/train")
def train_endpoint(user=Depends(require_user)):
    if user["plan"] not in ("professional","institutional"): raise HTTPException(403,"Training is restricted to professional/institutional accounts")
    return train()

@app.get("/api/v1/tws/metrics")
def metrics():
    if not META and not META_PATH.exists(): raise HTTPException(404,"No model metrics")
    return META or json.loads(META_PATH.read_text())

@app.post("/api/v1/tws/predict")
def tws_predict(r:TWSRequest,user=Depends(require_user)): return predict(r)

@app.get("/api/v1/water/cape-town")
def cape_town_water():
    return {"location":"Cape Town","status":"prediction-ready","message":"Provide prediction-time TWS_t, SPEI-1/3/6/12 and soil moisture through /api/v1/tws/predict. No future TWS is inferred.","area_km2":CAPE_TOWN_AREA_KM2}

@app.get("/api/v1/map/layers")
def layers():
    return {"layers":[{"id":"grace_tws","title":"GRACE TWS anomaly","group":"Water"},{"id":"soil_moisture","title":"Soil moisture","group":"Water"},{"id":"ndvi","title":"NDVI","group":"Nature"},{"id":"drought","title":"Drought risk","group":"Climate"},{"id":"surface_water","title":"Surface water","group":"Water"},{"id":"recharge","title":"Recharge potential (screening)","group":"Groundwater"},{"id":"nbs_priority","title":"NbS priority","group":"Nature-based Solutions"}]}

@app.get("/api/v1/groundtruth")
def get_gt(user=Depends(require_user)):
    with db() as c: rows=c.execute("SELECT * FROM groundtruth WHERE user_id=? ORDER BY observed_at DESC",(user["id"],)).fetchall()
    return [dict(r) for r in rows]

@app.post("/api/v1/groundtruth")
def post_gt(r:Groundtruth,user=Depends(require_user)):
    oid=str(uuid.uuid4()); observed=r.observed_at or datetime.now(timezone.utc).isoformat()
    with db() as c:c.execute("INSERT INTO groundtruth VALUES(?,?,?,?,?,?,?,?)",(oid,r.lat,r.lon,r.kind,r.value,r.notes,observed,user["id"]))
    return {"id":oid,"status":"stored"}

@app.get("/api/v1/gee/grace-tws-tile")
def grace_tile(user=Depends(require_user)):
    try:
        init_ee(); img=ee.ImageCollection("NASA/GRACE/MASS_GRIDS/MASCON_CRI").filterBounds(aoi()).sort("system:time_start",False).first().clip(aoi())
        return {"tile_url":img.getMapId({"min":-30,"max":30,"palette":["b2182b","fddbc7","d1e5f0","2166ac"]})["tile_fetcher"].url_format,"source":"NASA GRACE/GRACE-FO mascon","scale_m":25000}
    except Exception as e: raise HTTPException(503,f"Earth Engine unavailable: {e}")

@app.get("/",response_class=HTMLResponse)
def home():
    return '''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>ClimateNatureAI</title><style>body{font-family:system-ui;margin:0;background:#f4f7f4;color:#173b32}main{max-width:760px;margin:auto;padding:28px}.card{background:white;border-radius:18px;padding:20px;margin:14px 0;box-shadow:0 4px 18px #0001}button{padding:12px 16px;border:0;border-radius:10px;background:#173b32;color:white}input{padding:10px;margin:4px;width:90%}.metric{font-size:28px;font-weight:700}</style></head><body><main><h1>ClimateNatureAI</h1><p>Climate • Water • Biodiversity • Nature-based Solutions Intelligence</p><div class="card"><h2>💧 Water Intelligence</h2><div class="metric">Research + operational API</div><p>TWS forecasting, GRACE monitoring, soil moisture, drought, recharge screening and nature-based solutions.</p></div><div class="card"><h3>API</h3><p>Interactive documentation is available at <b>/docs</b>. Production deployment requires HTTPS, managed PostgreSQL/PostGIS, secret management, rate limiting and monitored Earth Engine service credentials.</p></div></main></body></html>'''

if __name__=="__main__":
    import uvicorn
    uvicorn.run("app.main:app",host=os.getenv("HOST","0.0.0.0"),port=int(os.getenv("PORT","8000")),reload=False)
