# ClimateNatureAI v5 — Research + Operational Platform

**Climate • Water • Biodiversity • Nature-based Solutions Intelligence**

> See the Risk. Find the Nature. Measure the Impact.

## What changed from the prototype

This version is deliberately designed as a **research + operational platform**, not only a mobile map. It separates the mobile client, API, model lifecycle, Earth Engine data services, database, field validation and deployment concerns.

### Core services

- FastAPI API gateway
- Authentication and plan/entitlement foundation
- TWS t+1 ML forecasting service
- Leakage-safe target generation
- Chronological evaluation
- Persistence benchmark
- Model metadata/provenance
- GRACE/GRACE-FO monitoring endpoint
- Groundtruth observations
- Climate/nature layer catalog
- Flutter mobile foundation
- Docker deployment
- PostgreSQL/PostGIS migration path

## TWS prediction protocol

Input schema:

`TWS_t, SPEI_1, SPEI_3, SPEI_6, SPEI_12, SOIL_MOISTURE_t, latitude, longitude, date`

Target:

`TWS_(t+1)`

The training pipeline creates the target only when the next row is the **next calendar month** for the same coordinate. It does not forward-fill or infer missing future TWS values.

The API requires all prediction-time predictors for inference. This is intentional: an operational system must obtain those predictors from validated current-data feeds rather than silently substituting an old training row.

## Research governance

Every production model should publish:

1. data sources and versions
2. feature definitions and units
3. prediction-time availability rules
4. train/validation/test periods
5. spatial and temporal evaluation
6. baseline comparison
7. uncertainty/error metrics
8. model version and training timestamp
9. data-quality flags
10. known limitations

## Scientific interpretation

GRACE/GRACE-FO TWS products are coarse-scale storage-change observations. A value expressed as equivalent water thickness can be converted to an equivalent volume for an area, but an anomaly-derived volume is **not the complete physical water inventory** of Cape Town.

Recharge, groundwater-dependent ecosystem and flood outputs must remain explicitly labelled as screening indicators unless calibrated/validated with appropriate hydrogeological or hydraulic observations.

## Production deployment checklist

- Managed PostgreSQL/PostGIS
- Redis + background job queue
- Object storage for datasets and model artifacts
- HTTPS / reverse proxy
- OAuth2/OIDC identity provider
- Secret manager
- Rate limiting and API quotas
- Structured logs and audit trail
- Prometheus/Grafana or cloud monitoring
- Error tracking
- Model registry
- Dataset/version registry
- App Store / Google Play subscription verification
- Earth Engine server-side credentials
- Automated tests and CI/CD
- Backups and disaster recovery

## Run locally

```bash
cp .env.example .env
pip install -r requirements.txt
earthengine authenticate
uvicorn app.main:app --app-dir backend --host 0.0.0.0 --port 8000
```

API docs: `http://localhost:8000/docs`

Put `Train.csv` in `data/`.

Register a professional/institutional user, then train:

```http
POST /api/v1/admin/tws/train
```

Prediction:

```http
POST /api/v1/tws/predict
```

Metrics:

```http
GET /api/v1/tws/metrics
```

## Docker

```bash
docker compose up --build
```

The included PostgreSQL/PostGIS service is the deployment path; the current API uses SQLite for a zero-dependency local development mode. Replace the persistence layer with SQLAlchemy/PostGIS before multi-user production launch.

## Mobile

```bash
cd flutter
flutter pub get
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:8000
```
