import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

const api = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:8000');
const secure = FlutterSecureStorage();

void main() => runApp(const ClimateNatureAI());
class ClimateNatureAI extends StatelessWidget { const ClimateNatureAI({super.key}); @override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,title:'ClimateNatureAI',theme:ThemeData(useMaterial3:true,colorSchemeSeed:Colors.teal),home:const Home()); }
class Home extends StatefulWidget { const Home({super.key}); @override State<Home> createState()=>_HomeState(); }
class _HomeState extends State<Home>{ int tab=0; Map<String,dynamic>? water; String msg='Ready';
 Future<void> load(){ return http.get(Uri.parse('$api/api/v1/water/cape-town')).then((r){setState((){water=jsonDecode(r.body);msg='Water intelligence loaded';});}).catchError((e){setState(()=>msg='API unavailable: $e');}); }
 @override void initState(){super.initState();load();}
 @override Widget build(BuildContext c){final pages=[_dashboard(),_map(),_water(),_nature(),_settings()];return Scaffold(appBar:AppBar(title:const Text('ClimateNatureAI')),body:pages[tab],bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:const [NavigationDestination(icon:Icon(Icons.dashboard),label:'Home'),NavigationDestination(icon:Icon(Icons.map),label:'Map'),NavigationDestination(icon:Icon(Icons.water_drop),label:'Water'),NavigationDestination(icon:Icon(Icons.eco),label:'Nature'),NavigationDestination(icon:Icon(Icons.settings),label:'Settings')]));}
 Widget card(String t,String v,IconData i)=>Card(child:ListTile(leading:Icon(i),title:Text(t),trailing:Text(v,style:const TextStyle(fontWeight:FontWeight.bold))));
 Widget _dashboard()=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Climate • Water • Biodiversity • NbS Intelligence',style:TextStyle(fontSize:16)),const SizedBox(height:16),card('Water status','Prediction-ready',Icons.water),card('TWS','GRACE + ML',Icons.analytics),card('Drought','Monitor',Icons.warning),card('Recharge','Screening',Icons.terrain),Text(msg),const SizedBox(height:10),FilledButton(onPressed:load,child:const Text('Refresh intelligence'))]);
 Widget _map()=>const Center(child:Text('Interactive Climate–Nature Map\n\nGRACE TWS • Soil Moisture • NDVI • Drought • Surface Water • Recharge • NbS'));
 Widget _water()=>ListView(padding:const EdgeInsets.all(16),children:[const Text('💧 Water Intelligence',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),const SizedBox(height:12),Text(water==null?'Loading…':jsonEncode(water)),const SizedBox(height:12),const Text('TWS forecasting uses prediction-time predictors and never fills masked TWS with future observations.')]);
 Widget _nature()=>const ListView(padding:EdgeInsets.all(16),children:[Text('🌱 Nature Intelligence',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),ListTile(title:Text('Ecosystem condition'),subtitle:Text('NDVI / land cover / soil moisture')),ListTile(title:Text('Recharge potential'),subtitle:Text('Screening indicator; requires hydrogeological calibration')),ListTile(title:Text('NbS priority'),subtitle:Text('Risk + ecosystem condition + exposure'))]);
 Widget _settings()=>const ListView(padding:EdgeInsets.all(16),children:[Text('Settings',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),ListTile(title:Text('API endpoint'),subtitle:Text(api)),ListTile(title:Text('Research mode'),subtitle:Text('Reproducible model metrics and provenance'))]);
}
